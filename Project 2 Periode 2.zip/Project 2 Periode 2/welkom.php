<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welkom</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <?php
    session_start();
    echo "Welkom " . $_SESSION["naam"];
    echo "<h4></h4>";
    if(isset($_POST["verzend"])){
        $_SESSION["naam"] = $_POST["naam"];
        $_SESSION["wachtwoord"] = $_POST["wachtwoord"];
    }
    if ($_SESSION["wachtwoord"] == 1234) {
        echo "<button>
                <a href='gar-menu.php'>Naar het garage menu.</a>
              </button>";

    } else {
        echo "<strong>U heeft geen autorisatie voor het garage menu.</strong>";
    }
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>