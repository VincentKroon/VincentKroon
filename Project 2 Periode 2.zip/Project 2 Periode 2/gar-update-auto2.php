<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Antjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-auto2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage update auto: Stap 2</h1>
    <p>
        Dit formulier wordt gebruikt om auto gegevens te wijzigen
        in de tabel klant van de database garage.
    </p>
    <?php
    // klantid uit het formulier halen ---------------------
    $kenteken = $_POST["kentekenvak"];

    // klantgegevens uit  de tabel halen -------------------
    require_once "gar-connect.php";

    $autos = $conn->prepare(
        "select klantid,
            kenteken,
            merk,
            type,
            kmstand
    from    autogegevens
    where   kenteken = :kenteken"
    );
    $autos->execute(["kenteken" => $kenteken]);

    // autogegevens in een nieuw formulier laten zien------
    echo "<form action='gar-update-auto3.php' method='post'>";
    foreach ($autos as $auto) {
        // klantid mag niet gewijzigd worden
        echo " klantid: <input type='text' ";
        echo " name = 'klantidvak' ";
        echo " value=' " . $auto['klantid'] . "' ";
        echo " > <br /> ";

        echo " kenteken: " . $auto['kenteken'];
        echo " <input type='hidden' name='autokentekenvak' ";
        echo " value=' " . $auto['kenteken'] . " '> <br /> ";

        echo " merk: <input type='text' ";
        echo " name = 'automerkvak' ";
        echo " value = '" . $auto['merk'] . "' ";
        echo " > <br />";

        echo " type: <input type='tekst' ";
        echo " name = 'autotypevak' ";
        echo " value = '" . $auto['type'] . "' ";
        echo " > <br />";

        echo " kmstand: <input type='text' ";
        echo " name = 'autokmstandvak' ";
        echo " value = '" . $auto['kmstand'] . "' ";
        echo " > <br />";

    }
    echo "<input type='submit'>";
    echo "</form>";

    // er moet eigenlijk nog gecontroleerd worden op een bestaand klantid
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
