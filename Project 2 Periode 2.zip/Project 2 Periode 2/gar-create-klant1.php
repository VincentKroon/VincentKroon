<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-create-klant1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage create klant: Stap 1</h1>
    <p>
        Dit formulier wordt gebruikt om klantgegevens in voeren.
    </p>
    <form action="gar-create-klant2.php" method="post">
        Klantnaam: <input type="text" name="klantnaamvak"> <br/>
        <h2></h2>
        Klantadres: <input type="text" name="klantadresvak"> <br/>
        <h2></h2>
        Klantpostcode:<input type="text" name="klantpostcodevak"> <br/>
        <h2></h2>
        Klantplaats: <input type="text" name="klantplaatsvak"> <br/>
        <h2></h2>
        <input type="submit">
    </form>
</main>
<footer>

</footer>
</body>
</html>
