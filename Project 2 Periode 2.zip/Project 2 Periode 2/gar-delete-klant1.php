<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-delete-klant1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage delete klant: Stap 1</h1>
    <p>Dit formulier zoekt een klant op uit de tabel klanten van database garage om hem te kunnen verwijderen.
    </p>
    <form action="gar-delete-klant2.php" method="post">
        Welk klantid wilt u verwijderen?
        <input type="text" name="klantidvak">   <br />
        <input type="submit">
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</form>
</body>
</html>