<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-delete-auto1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage delete auto: Stap 1</h1>
    <p>
        Dit formulier zoekt een kenteken op uit de tabel autos
        van database garage om hem te kunnen verwijderen.
    </p>
    <form action="gar-delete-auto2.php" method="post">
        Welk kenteken wilt u verwijderen?
        <input type="text" name="kentekenvak">   <br />
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>