<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title> Form </title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main class="main">

    <h1>Admin Login</h1>
    <form action="welkom.php" method="post">
        Gebruikersnaam:<br>
        <input type="text" id="voornaam" name="naam"><br>
        Wachtwoord: <br>
        <input type="password" id="wachtwoord" name="wachtwoord"><br><br>
        <input type="submit" value="Verzend" name="verzend">
    </form>
    <h4></h4>
    <a href="index.html">--Terug naar Home menu--</a>

</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
