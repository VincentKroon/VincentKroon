<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-create-auto2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage create auto: Stap 2</h1>
    <p>
        Een klant toevoegen aan de tabel
        klant in de database garage.
    </p>
    <?php
    // klantgegevens uit het formulier halen
    $klantid          = $_POST ["klantidvak"];
    $autokenteken     = $_POST ["autokentekenvak"];
    $automerk         = $_POST ["automerkvak"];
    $autotype         = $_POST ["autotypevak"];
    $autokmstand      = $_POST ["autokmstandvak"];

    // autogegevens invoeren in de tabel
    require_once "gar-connect.php";

    $sql = $conn->prepare("
            insert into autogegevens values (
                                      :klantid, :kenteken, :merk, 
                                      :type, :kmstand
                                      )
             ");

    //manier 2
    $sql->execute([
        "klantid"   => $klantid,
        "kenteken"  => $autokenteken,
        "merk"      => $automerk,
        "type"      => $autotype,
        "kmstand"   => $autokmstand,
    ]);
    echo "De klant is toegevoegd <br />";
    echo "<br>";
    echo "<a href='gar-menu.php'> terug naar het menu</a>"
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
