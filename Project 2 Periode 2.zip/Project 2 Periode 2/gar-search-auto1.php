<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-search-auto1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage zoek op kenteken: Stap 1</h1>
    <p>
        Dit formulier zoekt een auto op uit
        de tabel autos van de database garage
    </p>
    <form action="gar-search-auto2.php" method="post">
        Welk kenteken zoekt u?
        <input type="text" name="autokentekenvak"> <br />
        <h2></h2>
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>

