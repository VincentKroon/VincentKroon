<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-klant3.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage update klant: Stap 3</h1>
    <p>
        Klantgegevens wijzigen in de tabel
        klant van de database garage.
    </p>
    <?php
    // klantgegevens uit het formulier halen -------------------------------
    $klantid = $_POST["klantidvak"];
    $klantnaam = $_POST["klantnaamvak"];
    $klantadres = $_POST["klantadresvak"];
    $klantpostcode = $_POST["klantpostcodevak"];
    $klantplaats = $_POST["klantplaatsvak"];

    // updaten klantgegevens--------------------------------------------
    require_once "gar-connect.php";
    $sql = $conn->prepare
    ("
    update klantgegevens set    klantnaam           = :klantnaam,
                                klantadres          = :klantadres,
                                klantpostcode       = :klantpostcode,
                                klantplaats         = :klantplaats 
                                where       klantid = :klantid 
");

    $sql->execute
    ([
        "klantid" => $klantid,
        "klantnaam" => $klantnaam,
        "klantadres" => $klantadres,
        "klantpostcode" => $klantpostcode,
        "klantplaats" => $klantplaats,
    ]);

    echo "de klant is gewijzigd. <br />";
    echo "<br>";
    echo "<a href='gar-menu.php'> terug naar het menu </a>";
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
