<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-read-auto.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage read auto</h1>
    <p>
        Dit zijn alle gegevens uit de
        tabel autogegevens van de database garage.
    </p>

    <?php
    // tabel uitlezen en netjes afdrukken ----------------
    require_once "gar-connect.php";

    $autos = $conn->prepare(
        "select klantid,
                kenteken,
                merk,
                type,
                kmstand
        from    autogegevens
    ");
    $autos->execute();

    echo "<table>";
    foreach ($autos as $auto) {
        echo "<tr>";
        echo "<td>" . $auto["klantid"] . "</td>";
        echo "<td>" . $auto["kenteken"] . "</td>";
        echo "<td>" . $auto["merk"] . "</td>";
        echo "<td>" . $auto["type"] . "</td>";
        echo "<td>" . $auto["kmstand"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<a href='gar-menu.php'> terug naar het menu </a>";
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
