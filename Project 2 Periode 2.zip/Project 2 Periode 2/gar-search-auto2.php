<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-search-auto2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage zoek op kenteken: Stap 2</h1>
    <p>
        Op kenteken gegevens zoeken uit de
        tabel van de database garage.
    </p>
    <?php
    // klantid uit het formulier halen ----------------------
    $kenteken = $_POST["autokentekenvak"];

    // klantgegevens uit de tabel halen ---------------------
    require_once "gar-connect.php";

    $autos = $conn->prepare(
        "select klantid,
            kenteken,
            merk,
            type,
            kmstand
    from    autogegevens
    where   kenteken = :kenteken"
    );

    $autos->execute(["kenteken" => $kenteken]);

    echo "<table>";
    foreach ($autos as $auto) {
        echo "<tr>";
        echo "<td>" . $auto["klantid"] . "</td>";
        echo "<td>" . $auto["kenteken"] . "</td>";
        echo "<td>" . $auto["merk"] . "</td>";
        echo "<td>" . $auto["type"] . "</td>";
        echo "<td>" . $auto["kmstand"] . "</td>";
        echo "</tr>";
    }
    echo "</table><br />";
    echo "<a href='gar-menu.php'> terug naar het menu</a>";

    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
