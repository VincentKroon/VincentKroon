<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-create-auto1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage create auto: Stap 1</h1>
    <p>
        Dit formulier wordt gebruikt om autogegevens in voeren.
    </p>
    <form action="gar-create-auto2.php" method="post">
        Klantid:      <input type="text" name="klantidvak">     <br />
        <h2></h2>
        Kenteken:     <input type="text" name="autokentekenvak">     <br />
        <h2></h2>
        Merk:         <input type="text" name="automerkvak">         <br />
        <h2></h2>
        Type:         <input type="text" name="autotypevak">         <br />
        <h2></h2>
        Kmafstand:    <input type="text" name="autokmstandvak">    <br />
        <h2></h2>
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>