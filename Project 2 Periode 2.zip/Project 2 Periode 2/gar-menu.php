<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title> gar-menu.php </title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
<h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage menu</h1>
    <h2>Klant menu</h2>
    <ul>
        <li><button><a href="gar-create-klant1.php">Create</a></button></li>
        <li><button><a href="gar-read-klant.php">Read</a></button></li>
        <li><button><a href="gar-search-klant1.php">Zoeken op klant</a></button></li>
        <li><button><a href="gar-update-klant1.php">Update</a></button></li>
        <li><button><a href="gar-delete-klant1.php">Delete</a></button></li>
    </ul>

    <h2>Auto menu</h2>
    <ul>
        <li><button><a href="gar-create-auto1.php">Create</a></button></li>
        <li><button><a href="gar-read-auto.php">Read</a></button></li>
        <li><button><a href="gar-search-auto1.php">Zoeken op kenteken</a></button></li>
        <li><button><a href="gar-update-auto1.php">Update</a></button></li>
        <li><button><a href="gar-delete-auto1.php">Delete</a></button></li>
    </ul>
</main>
<footer>

</footer>
</body>
</html>