<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Antjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-klant2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage update klant: Stap 2</h1>
    <p>
        Dit formulier wordt gebruikt om klantgegevens te wijzigen
        in de tabel klant van de database garage.
    </p>
    <?php
    // klantid uit het formulier halen ---------------------
    $klantid = $_POST["klantidvak"];

    // klantgegevens uit  de tabel halen -------------------
    require_once "gar-connect.php";

    $klanten = $conn->prepare(
        "select klantid,
            klantnaam,
            klantadres,
            klantpostcode,
            klantplaats
    from    klantgegevens
    where klantid = :klantid"
    );
    $klanten->execute(["klantid" => $klantid]);

    // klantgegevens in een nieuw formulier laten zien------
    echo "<form action='gar-update-klant3.php' method='post'>";
    foreach ($klanten as $klant) {
        // klantid mag niet gewijzigd worden
        echo " Klantid: " . $klant["klantid"];
        echo "<br>";
        echo " <input type='hidden' name='klantidvak' ";
        echo " value=' " . $klant["klantid"] . " '> <br /> ";

        echo " Klantnaam: <input type='text' ";
        echo " name = 'klantnaamvak' ";
        echo " value = '" . $klant["klantnaam"] . "' ";
        echo " > <br />";
        echo "<br>";

        echo " Klantadres: <input type='text' ";
        echo " name = 'klantadresvak' ";
        echo " value = '" . $klant["klantadres"] . "' ";
        echo " > <br />";
        echo "<br>";

        echo " Klantpostcode: <input type='tekst' ";
        echo " name = 'klantpostcodevak' ";
        echo " value = '" . $klant["klantpostcode"] . "' ";
        echo " > <br />";
        echo "<br>";

        echo " Klantplaats: <input type='text' ";
        echo " name = 'klantplaatsvak' ";
        echo " value = '" . $klant["klantplaats"] . "' ";
        echo " > <br />";
        echo "<br>";

    }
    echo "<input type='submit'>";
    echo "</form>";

    // er moet eigenlijk nog gecontroleerd worden op een bestaand klantid
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>