<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-delete-auto2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage delete auto: Stap 2</h1>
    <p>
        Op kenteken gegevens zoeken uit de tabel autos van de database garage zodat ze verwijderd kunnen worden.
    </p>
    <?php
    // kenteken uit het formulier halen ----------------------------
    $kenteken = $_POST["kentekenvak"];

    // klantgegevens uit de tabel halen --------------------------
    require_once "gar-connect.php";

    $autos = $conn->prepare("
                                select  klantid,
                                        kenteken,
                                        merk,
                                        type,
                                        kmstand
                                from    autogegevens
                                where   kenteken = :kenteken
                                ");
    $autos->execute(["kenteken" => $kenteken]);

    // klantgegevens laten zien----------------------------------
    echo "<table>";
    foreach ($autos as $auto) {
        echo "<tr>";
        echo "<td>" . $auto["klantid"] . "</td>";
        echo "<td>" . $auto["kenteken"] . "</td>";
        echo "<td>" . $auto["merk"] . "</td>";
        echo "<td>" . $auto["type"] . "</td>";
        echo "<td>" . $auto["kmstand"] . "</td>";
        echo "</tr>";
    }
    echo "</table><br />";
    echo "<form action='gar-delete-auto3.php' method='post'>";
    // kenteken mag niet meer gewijzigd worden
    echo "<input type='hidden' name='kentekenvak' value='$kenteken'>";
    // Waarde 0 doorgegeven als er niet gecheckt wordt
    echo "<input type='hidden' name='verwijdervak' value='0'>";
    echo "<input type='checkbox' name='verwijdervak' value='1'>";
    echo "Verwijder deze klant. <br />";
    echo "<input type='submit'>";
    echo "</form>";
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>