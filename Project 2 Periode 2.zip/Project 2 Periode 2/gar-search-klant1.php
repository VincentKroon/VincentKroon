<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-search-klant1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage zoek op klantid: Stap 1</h1>
    <p>
        Dit formulier zoekt een klant op uit
        de tabel klanten van de database garage
    </p>
    <form action="gar-search-klant2.php" method="post">
        Welk klantid zoekt u?
        <input type="text" name="klantidvak"> <br />
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
