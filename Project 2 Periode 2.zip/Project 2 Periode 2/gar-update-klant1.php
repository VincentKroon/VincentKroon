<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-klant1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage update klant: Stap 1</h1>
    <p>
        Dit formulier wordt gebruikt om klantgegevens te wijzigen.
    </p>
    <form action="gar-update-klant2.php" method="post">
        Welk klantid wilt u wijzigen?
        <input type="text" name="klantidvak"> <br/>
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>
