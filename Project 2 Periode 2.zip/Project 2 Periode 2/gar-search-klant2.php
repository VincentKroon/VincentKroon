<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-search-klant2.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage zoek op klantid: Stap 2</h1>
    <p>
        Op klantid gegevens zoeken uit de
        tabel van de database garage.
    </p>
    <?php
    // klantid uit het formulier halen ----------------------
    $klantid = $_POST["klantidvak"];

    // klantgegevens uit de tabel halen ---------------------
    require_once "gar-connect.php";

    $klanten = $conn->prepare(
        "select klantid,
            klantnaam,
            klantadres,
            klantpostcode,
            klantplaats
    from    klantgegevens
    where   klantid = :klantid"
    );

    $klanten->execute(["klantid" => $klantid]);

    echo "<table>";
    foreach ($klanten as $klant) {
        echo "<tr>";
        echo "<td>" . $klant["klantid"] . "</td>";
        echo "<td>" . $klant["klantnaam"] . "</td>";
        echo "<td>" . $klant["klantadres"] . "</td>";
        echo "<td>" . $klant["klantpostcode"] . "</td>";
        echo "<td>" . $klant["klantplaats"] . "</td>";
        echo "</tr>";
    }
    echo "</table><br />";
    echo "<a href='gar-menu.php'> Terug naar het menu</a>";

    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>