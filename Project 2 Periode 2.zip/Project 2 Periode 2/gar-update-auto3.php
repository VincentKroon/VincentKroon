<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-auto3.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
  <h1>Home</h1>
</header>
<main>
    <h1>Garage update auto: Stap 3</h1>
    <p>
        autogegevens wijzigen in de tabel
        auto van de database garage.
    </p>
    <?php
    //autogegevens uit het formulier halen -------------------------------
    $klantid = $_POST["klantidvak"];
    $kenteken = $_POST["autokentekenvak"];
    $merk = $_POST["automerkvak"];
    $type = $_POST["autotypevak"];
    $kmstand = $_POST["autokmstandvak"];

    // updaten autogegevens----------------------------------------------
    try {
        require_once "gar-connect.php";

        $sql = "UPDATE autogegevens SET 
                                    klantid='$klantid', 
                                    merk='$merk',
                                    type='$type',
                                    kmstand='$kmstand'
                                    WHERE kenteken='$kenteken'";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // execute the query
        $stmt->execute();

        // echo a message to say the UPDATE succeeded
        echo $stmt->rowCount() . " records UPDATED successfully <br>";
    } catch(PDOException $e) {
        echo $sql . "<br>" . $e->getMessage();
    }

    $conn = null;
    //$sql = $conn->prepare
    //("
    //update autogegevens set     klantid     = :klantid,
    //                            kenteken    = :kenteken,
    //                            merk        = :merk,
    //                            type        = :type,
    //                            kmstand     = :kmstand
    //                            where       kenteken = :kenteken
    //");

    //$sql->execute
    //([
    //    "klantid"     => $klantid,
    //    "kenteken"    => $kenteken,
    //    "merk"        => $merk,
    //    "type"        => $type,
    //    "kmstand"     => $kmstand,
    //]);

    echo "de auto is gewijzigd. <br />";
    echo "<a href='gar-menu.php'> Terug naar het menu </a>";
    ?>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>