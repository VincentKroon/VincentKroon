<?php

echo "<p>Copyright &copy; 2021-" . date("Y") . " Anjo Eijeriks</p>";

?>