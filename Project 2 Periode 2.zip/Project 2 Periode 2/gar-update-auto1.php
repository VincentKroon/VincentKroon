<!DOCTYPE html>
<html lang="nl">
<head>
    <meta name="author" content="Anjo Eijeriks">
    <meta charset="UTF-8">
    <title>gar-update-auto1.php</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
<header>
    <h1><a class="home" href="welkom.php">Home</a></h1>
</header>
<main>
    <h1>Garage update auto: Stap 1</h1>
    <p>
        Dit formulier wordt gebruikt om autogegevens te wijzigen.
    </p>
    <form action="gar-update-auto2.php" method="post">
        Vul de gewenste kenteken in:
        <input type="text" name="kentekenvak"> <br />
        <h2></h2>
        <input type="submit">
    </form>
</main>
<footer>
    <?php include'footer.php';?>
</footer>
</body>
</html>